#include <iostream>

// En funksjon som har paramtre og returverdi
// Sagt på en annen måte: En funksjon som tar inn argumenter og 
// returnerer en verdi
int add(int a, int b) {
    return a + b;
}

// En funksjon som leser inn input fra bruker og skriver ut til skjerm
void inputIntegersAndPrintProduct() {
    int x = 0;
    int y = 0;
    std::cout << "Skriv inn to heltall: ";
    std::cin >> x;
    std::cin >> y;
    
    int product = x * y;
    
    std::cout << x << " * " << y << " = " << product << std::endl;
}

int main() {
    int sumOfOneAndTwo = add(1, 2);
    std::cout << "1 + 2 = " << sumOfOneAndTwo << std::endl;
    
    // Funksjonskall kan settes rett inn der man vil ha verdien:
    std::cout << "2 + 2 = " << add(2, 2) << std::endl;
	
    inputIntegersAndPrintProduct();
}